package utils;

public enum Browser {
    CHROME, FIREFOX, EDGE, IE, OPERA;
}
