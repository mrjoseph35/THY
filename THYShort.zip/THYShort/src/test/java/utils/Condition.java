package utils;

public enum Condition {
    exist,
    visible,
    clickable,
    enable,
    appear,
    disappear
    ;
}
